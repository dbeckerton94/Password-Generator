﻿
using System.Configuration;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PasswordExercise.CustomExceptions;
using PasswordExercise.Models;
using PasswordExercise.Utility;

namespace PasswordExcercise.Tests
{
	[TestClass]
	public class PasswordGeneratorTests
	{
		[TestMethod]
		public void TestGenerateLengthOnly()
		{
			PasswordGenerator generator = new PasswordGenerator();

			string result = generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = 16,
				MinLength = 8,
			});
			
			Assert.IsTrue(result.Length >= 8 && result.Length <= 16);
		}

		[TestMethod]
		public void TestCanRetrieveMinLengthConfigValue()
		{
			PasswordRequirementsUtility passwordRequirementsUtility = new PasswordRequirementsUtility();
			int value = passwordRequirementsUtility.MinimumLengthPasswordRequirement();
			Assert.IsNotNull(value);
			Assert.IsTrue(value > 0);
		}

		[TestMethod]
		public void TestCanRetrieveMaxLengthConfigValue()
		{
			PasswordRequirementsUtility passwordRequirementsUtility = new PasswordRequirementsUtility();
			int value = passwordRequirementsUtility.MaximumLengthPasswordRequirement();
			Assert.IsNotNull(value);
			Assert.IsTrue(value > 0);
		}

		[TestMethod]
		public void TestMinLengthGreaterThanMaxLength()
		{
			PasswordGenerator generator = new PasswordGenerator();
			var ex = Assert.ThrowsException<PasswordGeneratorException>(() => generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = 7,
				MinLength = 8,
			}));

			Assert.AreEqual(ex.Message, "MaxLength must be greater than MinLength.");
		}

		[TestMethod]
		public void TestNegativeMinLength()
		{
			PasswordGenerator generator = new PasswordGenerator();
			PasswordRequirementsUtility passwordRequirementsUtility = new PasswordRequirementsUtility();

			int value = passwordRequirementsUtility.MinimumLengthPasswordRequirement();
			var ex = Assert.ThrowsException<PasswordGeneratorException>(() => generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = 7,
				MinLength = -3,
			}));

			Assert.AreEqual(ex.Message, "MinLength must be greater than " + value + "for security purposes.");
		}


		[TestMethod]
		public void TestToLongLength()
		{
			PasswordGenerator generator = new PasswordGenerator();
			PasswordRequirementsUtility passwordRequirementsUtility = new PasswordRequirementsUtility();

			int value = passwordRequirementsUtility.MaximumLengthPasswordRequirement();
			var ex = Assert.ThrowsException<PasswordGeneratorException>(() => generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = 74,
				MinLength = 6,
			}));

			Assert.AreEqual(ex.Message, "MaxLength is greater than the aloud size of " + value);
		}

		[TestMethod]
		public void TestNegativeMaxLength()
		{
			PasswordGenerator generator = new PasswordGenerator();
			var ex = Assert.ThrowsException<PasswordGeneratorException>(() => generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = -7,
				MinLength = 8,
			}));

			Assert.AreEqual(ex.Message, "MaxLength must be greater than 0.");
		}

		[TestMethod]
		public void TestNullPasswordRequirementsObject()
		{
			PasswordGenerator generator = new PasswordGenerator();
			var ex = Assert.ThrowsException<PasswordGeneratorException>(() => generator.GeneratePassword(null));

			Assert.AreEqual(ex.Message, "PasswordRequirements required.");
		}

		[TestMethod]
		public void TestMoreLetterRequirementsThanMaxLengthValue()
		{
			PasswordGenerator generator = new PasswordGenerator();
			var ex = Assert.ThrowsException<PasswordGeneratorException>(() => generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = 8,
				MinLength = 1,
				MinLowerAlphaChars = 2,
				MinUpperAlphaChars = 2,
				MinNumericChars = 2,
				MinSpecialChars = 3
			}));

			Assert.AreEqual(ex.Message, "MaxLength must be greater than the letters required.");
		}

		[TestMethod]
		public void TestGenerateAllRequirements()
		{
			PasswordGenerator generator = new PasswordGenerator();

			string result = generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = 16,
				MinLength = 8,
				MinLowerAlphaChars = 1,
				MinUpperAlphaChars = 1,
				MinNumericChars = 1,
				MinSpecialChars = 1
			});

			Assert.IsTrue(result.Length >= 8 && result.Length <= 16);
			Assert.IsTrue(result.Any(char.IsUpper));
			Assert.IsTrue(result.Any(char.IsLower));
			Assert.IsTrue(result.Any(char.IsNumber));
			Assert.IsTrue(result.Any(char.IsSymbol) || result.Any(char.IsPunctuation));
		}

		[TestMethod]
		public void TestGenerateAllRequirments_Multiple()
		{
			PasswordGenerator generator = new PasswordGenerator();

			string result = generator.GeneratePassword(new PasswordRequirements()
			{
				MaxLength = 8,
				MinLength = 8,
				MinLowerAlphaChars = 2,
				MinUpperAlphaChars = 2,
				MinNumericChars = 2,
				MinSpecialChars = 2
			});

			Assert.IsTrue(result.Length == 8);
			Assert.IsTrue(result.Where(char.IsUpper).Count() == 2);
			Assert.IsTrue(result.Where(char.IsLower).Count() == 2);
			Assert.IsTrue(result.Where(char.IsNumber).Count() == 2);

			int countSpecial = result.Count(char.IsSymbol) + result.Count(char.IsPunctuation);
			Assert.IsTrue(countSpecial == 2);
		}
	}
}
