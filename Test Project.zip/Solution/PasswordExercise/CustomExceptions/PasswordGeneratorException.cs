﻿using System;
using System.Runtime.Serialization;

namespace PasswordExercise.CustomExceptions
{
    public class PasswordGeneratorException : Exception
    {
        public PasswordGeneratorException(string message): base(message)
        {
        }
        public PasswordGeneratorException(string message, Exception innerException): base(message, innerException)
        {
        }
        public PasswordGeneratorException(SerializationInfo info, StreamingContext context): base(info, context)
        {
        }
    }
}
