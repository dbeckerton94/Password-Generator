﻿using PasswordExercise.Interfaces;
using System.Configuration;

namespace PasswordExercise.Utility
{

    public class PasswordRequirementsUtility : IPasswordConfig
    {
        public int MinimumLengthPasswordRequirement()
        {
             return int.Parse(ConfigurationManager.AppSettings["MinLengthPasswordRequirement"]); 
        }
        public int MaximumLengthPasswordRequirement()
        {
            return int.Parse(ConfigurationManager.AppSettings["MaxLengthPasswordRequirement"]); 
        } 
    }
}
