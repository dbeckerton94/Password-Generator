﻿using PasswordExercise;
using PasswordExercise.CustomExceptions;
using PasswordExercise.Models;
using PasswordExercise.Utility;
using System;
using System.Collections.Generic;
using System.Text;

namespace PasswordExcercise
{
	public class PasswordGenerator : IPasswordGenerator
	{
		const string lowercaseCharacters = "abcdefghijklmnopqrstuvwxyz";
		const string uppercaseCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		const string specialCharacters = "!@#$%^&*_-=+";
		const string numericCharacters = "0123456789";
		const string allCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*_-=+0123456789";
		readonly Random random = new Random();
		
		public string GeneratePassword(PasswordRequirements passwordRequirements)
		{
			try
			{			
				ValidatePasswordRequirements(passwordRequirements);

				int minLowerAlphaChars = passwordRequirements.MinLowerAlphaChars;
				int minNumericChars = passwordRequirements.MinNumericChars;
				int minSpecialChars = passwordRequirements.MinSpecialChars;
				int minUpperAlphaChars = passwordRequirements.MinUpperAlphaChars;

				int passwordLength = GenerateRandomPasswordLength(passwordRequirements.MinLength, passwordRequirements.MaxLength);

				var passwordBuilder = new StringBuilder();
				for (int i = 0; i < passwordLength; i++)
				{
					if(minLowerAlphaChars > 0)
					{
						passwordBuilder.Append(GetRandomCharacter(lowercaseCharacters));
						minLowerAlphaChars--;
						continue;
					}
				
					if (minNumericChars > 0)
					{
						passwordBuilder.Append(GetRandomCharacter(numericCharacters));
						minNumericChars--;
						continue;
					}

					if (minSpecialChars > 0)
					{
						passwordBuilder.Append(GetRandomCharacter(specialCharacters));
						minSpecialChars--;
						continue;
					}

					if (minUpperAlphaChars > 0)
					{
						passwordBuilder.Append(GetRandomCharacter(uppercaseCharacters));
						minUpperAlphaChars--;
						continue;
					}

					passwordBuilder.Append(GetRandomCharacter(allCharacters));
				}

				string password = ShuffleGeneratedPassword(passwordBuilder.ToString());
				return password;

			}
			catch (PasswordGeneratorException ex)
			{
				Console.WriteLine(ex.Message);
				throw ex;
			}		
		}

		private void ValidatePasswordRequirements(PasswordRequirements passwordRequirements)
		{
			if (passwordRequirements == null)
			{
				throw new PasswordGeneratorException("PasswordRequirements required.");
			}

			if (passwordRequirements.MaxLength <= 0)
			{
				throw new PasswordGeneratorException("MaxLength must be greater than 0.");
			}

			if (passwordRequirements.MinLength > passwordRequirements.MaxLength)
			{
				throw new PasswordGeneratorException("MaxLength must be greater than MinLength.");
			}

			int lettersRequired = passwordRequirements.MinLowerAlphaChars + passwordRequirements.MinNumericChars + passwordRequirements.MinSpecialChars + passwordRequirements.MinUpperAlphaChars;

			if (lettersRequired > passwordRequirements.MaxLength)
			{
				throw new PasswordGeneratorException("MaxLength must be greater than the letters required.");
			}

			int minimumLengthPasswordRequirement = MinimumLengthPasswordRequirement();
			int maximumLengthPasswordRequirement = MaximumLengthPasswordRequirement();

			if (minimumLengthPasswordRequirement > passwordRequirements.MinLength)
			{
				throw new PasswordGeneratorException("MinLength must be greater than " + minimumLengthPasswordRequirement + "for security purposes.");
			}

			if (passwordRequirements.MaxLength > maximumLengthPasswordRequirement)
			{
				throw new PasswordGeneratorException("MaxLength is greater than the aloud size of " + maximumLengthPasswordRequirement);
			}
		}

		private int GenerateRandomPasswordLength(int minimumLength, int maximumLength)
		{
			return random.Next(minimumLength, maximumLength);
		}

		private char GetRandomCharacter(string characterDataset)
		{		
			int position = random.Next(0, characterDataset.Length - 1);
			return characterDataset[position];
		}

		private string ShuffleGeneratedPassword(string generatedPassword)
		{	
			int index;
			List<char> chars = new List<char>(generatedPassword);
			StringBuilder sb = new StringBuilder();
			while (chars.Count > 0)
			{
				index = random.Next(chars.Count);
				sb.Append(chars[index]);
				chars.RemoveAt(index);
			}
			return sb.ToString();
		}

		private int MinimumLengthPasswordRequirement()
		{
			PasswordRequirementsUtility passwordRequirementsUtility = new PasswordRequirementsUtility();
			int minimumLengthPasswordRequirement = passwordRequirementsUtility.MinimumLengthPasswordRequirement();
			return minimumLengthPasswordRequirement; 
		}

		private int MaximumLengthPasswordRequirement()
		{
			PasswordRequirementsUtility passwordRequirementsUtility = new PasswordRequirementsUtility();
			int maximumLengthPasswordRequirement = passwordRequirementsUtility.MaximumLengthPasswordRequirement();
			return maximumLengthPasswordRequirement;
		}
	}
}
