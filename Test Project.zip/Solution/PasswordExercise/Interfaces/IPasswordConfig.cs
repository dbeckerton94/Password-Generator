﻿namespace PasswordExercise.Interfaces
{
    public interface IPasswordConfig
    {
        int MinimumLengthPasswordRequirement();
        int MaximumLengthPasswordRequirement();
    }
}
