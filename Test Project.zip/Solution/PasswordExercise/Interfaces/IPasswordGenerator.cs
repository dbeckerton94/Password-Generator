﻿using PasswordExercise.Models;

namespace PasswordExercise
{
	public interface IPasswordGenerator
	{
		string GeneratePassword(PasswordRequirements requirements);
	}
}
