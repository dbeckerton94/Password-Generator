As part of your application to work at Data Interchange, could I please ask that you complete the attached exercise. This is a straightforward C# application, which requires a password to be generated based on requirements for the number of different character types in a string.

There are some unit tests provided, which will help you develop the solution. If necessary, please feel free to change/extend the interface and add more unit tests should you wish to provide further coverage. Equally, you are free to change the structure of the solution if you prefer to use dependency injection. The main purpose of this excercise is to understand the way you construct / design your code.

We don�t expect you to spend more than 90 minutes on this exercise. 
